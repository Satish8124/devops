sudo apt update -y
sudo apt install maven -y
mvn -version
